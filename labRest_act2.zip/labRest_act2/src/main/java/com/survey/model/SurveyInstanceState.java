// SurveyInstanceState.java - Enum for survey instance states
package com.survey.model;

public enum SurveyInstanceState {
    CREATED, IN_PROGRESS, COMPLETED
}