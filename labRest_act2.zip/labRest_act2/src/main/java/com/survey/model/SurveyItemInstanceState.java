// SurveyItemInstanceState.java
package com.survey.model;

public enum SurveyItemInstanceState {
    NOT_COMPLETED, COMPLETED
}