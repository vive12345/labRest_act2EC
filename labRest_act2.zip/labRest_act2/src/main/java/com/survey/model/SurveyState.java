// SurveyState.java - Enum for survey states
package com.survey.model;

public enum SurveyState {
    CREATED, COMPLETED, DELETED
}